drop table ARES_APP_BUSITYPE cascade constraints;

drop table ARES_APP_INFO cascade constraints;

drop table ARES_APP_ROLE cascade constraints;

drop table ARES_APP_VERSION cascade constraints;

drop table ARES_APP_VERSION_AUDIT cascade constraints;

drop table ARES_APP_VERSION_ORGN cascade constraints;

drop table ARES_APP_VERSION_PIC cascade constraints;

drop table ARES_DEVICE_APP cascade constraints;

drop table ARES_DEVICE_APPVER cascade constraints;

drop table ARES_DEVICE_BOUND_RELATION cascade constraints;

drop table ARES_DEVICE_INFO cascade constraints;

drop table ARES_EVENT_CONFIG cascade constraints;

drop table ARES_FILE_TAB cascade constraints;

drop table ARES_KEY_SEQUENCE cascade constraints;

drop table ARES_LOG_INFO cascade constraints;

drop table ARES_NOTE cascade constraints;

drop table ARES_SESSION cascade constraints;

drop table ARES_SESSION_HIS cascade constraints;

drop table ARES_SESSION_LOG cascade constraints;

drop table DEVICE_CRASH_LOG cascade constraints;

drop table MGG_TRANS_LOG cascade constraints;

drop table MGJ_BRANCH_CITY cascade constraints;

drop table MGJ_BRANCH_INFO cascade constraints;

drop table MGJ_BRANCH_PROVINCE cascade constraints;

drop table MGJ_BRANCH_TOWN cascade constraints;

drop table MZJ_BANNER_DATA cascade constraints;

drop table MZJ_FILES_DATA cascade constraints;

drop table MZJ_PROPA_DATA cascade constraints;

drop index SYS_AREA_PARENT_IDS;

drop index SYS_AREA_PARENT_ID;

drop index SYS_AREA_DEL_FLAG;

drop table SYS_AREA cascade constraints;

drop table SYS_CHECK_CONFIG cascade constraints;

drop table SYS_CHECK_DETAIL cascade constraints;

drop index SYS_CHECK_INFO_STATUS;

drop index SYS_CHECK_INFO_CONFIG_ID;

drop table SYS_CHECK_INFO cascade constraints;

drop index SYS_DICT_VALUE;

drop index SYS_DICT_LABEL;

drop index SYS_DICT_DEL_FLAG;

drop table SYS_DICT cascade constraints;

drop table SYS_ENTITY_ATTRIBUTE cascade constraints;

drop table SYS_LOG cascade constraints;

drop index SYS_MENU_PARENT_IDS;

drop index SYS_MENU_PARENT_ID;

drop index SYS_MENU_DEL_FLAG;

drop table SYS_MENU cascade constraints;

drop table SYS_MOBILE_MENU cascade constraints;

drop table SYS_MOBILE_ROLE_MENU cascade constraints;

drop index SYS_OFFICE_PARENT_IDS;

drop index SYS_OFFICE_PARENT_ID;

drop index SYS_OFFICE_DEL_FLAG;

drop table SYS_ORGAN cascade constraints;

drop index SYS_ROLE_DEL_FLAG;

drop table SYS_ROLE cascade constraints;

drop table SYS_ROLE_MENU cascade constraints;

drop table SYS_ROLE_OFFICE cascade constraints;

drop index SYS_USER_UPDATE_DATE;

drop index SYS_USER_OFFICE_ID;

drop index SYS_USER_LOGIN_NAME;

drop index SYS_USER_DEL_FLAG;

drop index SYS_USER_COMPANY_ID;

drop table SYS_USER cascade constraints;

drop table SYS_USER_ROLE cascade constraints;

/*==============================================================*/
/* Table: ARES_APP_BUSITYPE                                     */
/*==============================================================*/
create table ARES_APP_BUSITYPE 
(
   APP_BUSI_TYPE_ID     VARCHAR2(64)         not null,
   PAR_APP_BUSI_TYPE_ID VARCHAR2(64),
   APP_BUSI_TYPE_NAME   VARCHAR2(200),
   APP_BUSI_TYPE_CODE   VARCHAR2(100),
   APP_BUSI_TYPE_IMG    VARCHAR2(200),
   constraint PK_MAP_APP_TYPE primary key (APP_BUSI_TYPE_ID)
);

comment on table ARES_APP_BUSITYPE is
'应用分类表';

comment on column ARES_APP_BUSITYPE.APP_BUSI_TYPE_ID is
'业务类型编号';

comment on column ARES_APP_BUSITYPE.PAR_APP_BUSI_TYPE_ID is
'父业务类型编号';

comment on column ARES_APP_BUSITYPE.APP_BUSI_TYPE_NAME is
'业务类型中文名称';

comment on column ARES_APP_BUSITYPE.APP_BUSI_TYPE_CODE is
'业务类型英文名称';

comment on column ARES_APP_BUSITYPE.APP_BUSI_TYPE_IMG is
'业务应用类型图片';

/*==============================================================*/
/* Table: ARES_APP_INFO                                         */
/*==============================================================*/
create table ARES_APP_INFO 
(
   APP_ID               VARCHAR2(64)         not null,
   APP_TYPE             VARCHAR2(64)         not null,
   APP_NAME             VARCHAR2(200),
   APP_BUSI_TYPE_ID     VARCHAR2(64),
   APP_CODE             VARCHAR2(100),
   APP_ICO              VARCHAR2(200),
   APP_STATUS           VARCHAR2(1),
   APP_CREATE_DTIME     VARCHAR2(19),
   APP_OS               VARCHAR2(1),
   APP_PACKAGE          VARCHAR2(80),
   APP_ACTIVITY         VARCHAR2(80),
   PROV_ID              VARCHAR2(64),
   ORG_ID               VARCHAR2(64),
   APP_AUTH_STATUS      VARCHAR2(1),
   APP_DESC             VARCHAR2(1024),
   LATEST_VER_ID        VARCHAR2(20),
   SECRET_KEY           VARCHAR2(32),
   APP_CREATOR_USER     VARCHAR2(64),
   DEFAULT_AUDIT        VARCHAR2(1),
   DEFAULT_EXTEND       VARCHAR2(1),
   constraint PK_MAP_APP primary key (APP_ID)
);

comment on table ARES_APP_INFO is
'应用表';

comment on column ARES_APP_INFO.APP_ID is
'应用编号';

comment on column ARES_APP_INFO.APP_TYPE is
'应用类型编号 (1：原生应用，2：WEB应用）';

comment on column ARES_APP_INFO.APP_NAME is
'应用名称';

comment on column ARES_APP_INFO.APP_BUSI_TYPE_ID is
'业务类型';

comment on column ARES_APP_INFO.APP_CODE is
'英文名称';

comment on column ARES_APP_INFO.APP_ICO is
'应用图标';

comment on column ARES_APP_INFO.APP_STATUS is
'应用状态（0：不可用，1：可用）';

comment on column ARES_APP_INFO.APP_CREATE_DTIME is
'创建时间';

comment on column ARES_APP_INFO.APP_OS is
'应用操作系统 (1：Android， 2：IOS， 3：wphone)';

comment on column ARES_APP_INFO.APP_PACKAGE is
'应用PACKAGE';

comment on column ARES_APP_INFO.APP_ACTIVITY is
'应用ACTIVITY';

comment on column ARES_APP_INFO.PROV_ID is
'厂商编号';

comment on column ARES_APP_INFO.ORG_ID is
'发布机构';

comment on column ARES_APP_INFO.APP_AUTH_STATUS is
'授权状态 (1：公共， 2：授权)';

comment on column ARES_APP_INFO.APP_DESC is
'应用功能说明';

comment on column ARES_APP_INFO.LATEST_VER_ID is
'应用最新版本号';

comment on column ARES_APP_INFO.SECRET_KEY is
'应用密钥';

/*==============================================================*/
/* Table: ARES_APP_ROLE                                         */
/*==============================================================*/
create table ARES_APP_ROLE 
(
   APP_ID               VARCHAR2(64)         not null,
   ROLE_ID              VARCHAR2(64)         not null
);

comment on table ARES_APP_ROLE is
'应用-角色表';

comment on column ARES_APP_ROLE.APP_ID is
'应用编号';

comment on column ARES_APP_ROLE.ROLE_ID is
'角色编号';

/*==============================================================*/
/* Table: ARES_APP_VERSION                                      */
/*==============================================================*/
create table ARES_APP_VERSION 
(
   APP_VERS_ID          VARCHAR2(64)         not null,
   APP_ID               VARCHAR2(64)         not null,
   APP_VERS             VARCHAR2(8),
   APP_SIZE             NUMBER(19,0),
   APP_PATH             VARCHAR2(200),
   APP_CREATE_USER      VARCHAR2(20),
   APP_CREATE_DATE      VARCHAR2(10),
   APP_PUBLISH_DATE     VARCHAR2(10),
   APP_IS_UPDATE        VARCHAR2(1),
   APP_VERS_INDEX       NUMBER(5,0),
   APP_VERS_DESC        VARCHAR2(1024),
   APP_AUDIT_STATUS     VARCHAR2(1),
   RES_TYPE             VARCHAR2(1),
   RES_PATH             VARCHAR2(200),
   RES_SIZE             NUMBER(12,0),
   RES_UPDATE_PACK_PATH VARCHAR2(200),
   RES_UPDATE_PACK_SIZE VARCHAR2(10),
   APP_EXTEND_STATUS    VARCHAR2(1)          default '0',
   RES_UPLOAD_MODE      VARCHAR2(1),
   RES_URL              VARCHAR2(1024),
   RES_UPDATE_PACK_URL  VARCHAR2(1024),
   PLIST_FILE_PATH      VARCHAR2(200),
   constraint PK_MAP_APP_VERS primary key (APP_VERS_ID)
);

comment on table ARES_APP_VERSION is
'应用版本表';

comment on column ARES_APP_VERSION.APP_VERS_ID is
'应用版本编号';

comment on column ARES_APP_VERSION.APP_ID is
'应用编号';

comment on column ARES_APP_VERSION.APP_VERS is
'应用版本';

comment on column ARES_APP_VERSION.APP_SIZE is
'应用大小：资源包大小+升级包大小';

comment on column ARES_APP_VERSION.APP_PATH is
'应用路径：外部可访问此应用的路径';

comment on column ARES_APP_VERSION.APP_CREATE_USER is
'发布人：创建版本的人';

comment on column ARES_APP_VERSION.APP_CREATE_DATE is
'创建日期';

comment on column ARES_APP_VERSION.APP_PUBLISH_DATE is
'发布日期：审核通过的日期';

comment on column ARES_APP_VERSION.APP_IS_UPDATE is
'是否强制更新';

comment on column ARES_APP_VERSION.APP_VERS_INDEX is
'版本序列';

comment on column ARES_APP_VERSION.APP_VERS_DESC is
'版本描述';

comment on column ARES_APP_VERSION.APP_AUDIT_STATUS is
'审核状态：
待审核：1，
审核通过：2，
审核不通过：3，';

comment on column ARES_APP_VERSION.RES_TYPE is
'资源类型：
原生资源：1，
web资源：2，

通过数据字典配置';

comment on column ARES_APP_VERSION.RES_PATH is
'资源包路径';

comment on column ARES_APP_VERSION.RES_SIZE is
'资源包大小';

comment on column ARES_APP_VERSION.RES_UPDATE_PACK_PATH is
'升级包路径';

comment on column ARES_APP_VERSION.RES_UPDATE_PACK_SIZE is
'升级包大小';

comment on column ARES_APP_VERSION.APP_EXTEND_STATUS is
'推广状态';

comment on column ARES_APP_VERSION.RES_UPLOAD_MODE is
'资源上传方式';

comment on column ARES_APP_VERSION.RES_URL is
'资源包URL';

comment on column ARES_APP_VERSION.RES_UPDATE_PACK_URL is
'升级包URL';

comment on column ARES_APP_VERSION.PLIST_FILE_PATH is
'plist文件路径';

/*==============================================================*/
/* Table: ARES_APP_VERSION_AUDIT                                */
/*==============================================================*/
create table ARES_APP_VERSION_AUDIT 
(
   APP_AUDIT_ID         VARCHAR2(64)         not null,
   APP_ID               VARCHAR2(64),
   APP_VERS_ID          VARCHAR2(64)         not null,
   APP_AUDIT_STATUS     VARCHAR2(1),
   APP_AUDIT_SUGGESTION VARCHAR2(1024),
   APP_AUDIT_USER       VARCHAR2(20),
   APP_AUDIT_DTIME      DATE,
   APP_EXTEND_STATUS    VARCHAR2(1)          default '0',
   constraint PK_MAP_AUD_INFO primary key (APP_AUDIT_ID)
);

comment on table ARES_APP_VERSION_AUDIT is
'应用版本审核表';

comment on column ARES_APP_VERSION_AUDIT.APP_AUDIT_ID is
'审核编号';

comment on column ARES_APP_VERSION_AUDIT.APP_ID is
'应用编号';

comment on column ARES_APP_VERSION_AUDIT.APP_VERS_ID is
'应用版本编号';

comment on column ARES_APP_VERSION_AUDIT.APP_AUDIT_STATUS is
'审核状态';

comment on column ARES_APP_VERSION_AUDIT.APP_AUDIT_SUGGESTION is
'审核意见';

comment on column ARES_APP_VERSION_AUDIT.APP_AUDIT_USER is
'审核员';

comment on column ARES_APP_VERSION_AUDIT.APP_AUDIT_DTIME is
'审核时间';

comment on column ARES_APP_VERSION_AUDIT.APP_EXTEND_STATUS is
'推广状态';

/*==============================================================*/
/* Table: ARES_APP_VERSION_ORGN                                 */
/*==============================================================*/
create table ARES_APP_VERSION_ORGN 
(
   APP_ID               VARCHAR2(20)         not null,
   APP_VERS_ID          VARCHAR2(20)         not null,
   APP_ORGN             VARCHAR2(500)        not null
);

comment on table ARES_APP_VERSION_ORGN is
'应用版本机构表';

comment on column ARES_APP_VERSION_ORGN.APP_ID is
'应用编号';

comment on column ARES_APP_VERSION_ORGN.APP_VERS_ID is
'应用版本编号';

comment on column ARES_APP_VERSION_ORGN.APP_ORGN is
'使用机构';

/*==============================================================*/
/* Table: ARES_APP_VERSION_PIC                                  */
/*==============================================================*/
create table ARES_APP_VERSION_PIC 
(
   APP_PIC_ID           VARCHAR2(64)         not null,
   APP_ID               VARCHAR2(64),
   APP_VERS_ID          VARCHAR2(64),
   APP_PIC_PATH         VARCHAR2(200),
   constraint PK_APP_VERS_PIC primary key (APP_PIC_ID)
);

comment on table ARES_APP_VERSION_PIC is
'应用版本图片表';

comment on column ARES_APP_VERSION_PIC.APP_PIC_ID is
'应用版本图片编号';

comment on column ARES_APP_VERSION_PIC.APP_ID is
'应用编号';

comment on column ARES_APP_VERSION_PIC.APP_VERS_ID is
'应用版本编号';

comment on column ARES_APP_VERSION_PIC.APP_PIC_PATH is
'图片路径';

/*==============================================================*/
/* Table: ARES_DEVICE_APP                                       */
/*==============================================================*/
create table ARES_DEVICE_APP 
(
   DEVAPP_ID            VARCHAR2(64)         not null,
   APP_CODE             VARCHAR2(64),
   APP_NAME             VARCHAR2(200),
   APP_TYPE             VARCHAR2(16),
   APP_CREATOR          VARCHAR2(64),
   APP_CREATE_TIME      DATE,
   APP_SYSTEM           VARCHAR2(16),
   constraint PK_ARES_DEVICE_APP primary key (DEVAPP_ID)
);

comment on table ARES_DEVICE_APP is
'设备应用表';

comment on column ARES_DEVICE_APP.DEVAPP_ID is
'标识';

comment on column ARES_DEVICE_APP.APP_CODE is
'应用标识';

comment on column ARES_DEVICE_APP.APP_NAME is
'应用名称';

comment on column ARES_DEVICE_APP.APP_TYPE is
'应用类型';

comment on column ARES_DEVICE_APP.APP_CREATOR is
'创建人';

comment on column ARES_DEVICE_APP.APP_CREATE_TIME is
'创建时间';

/*==============================================================*/
/* Table: ARES_DEVICE_APPVER                                    */
/*==============================================================*/
create table ARES_DEVICE_APPVER 
(
   ID                   VARCHAR2(64)         not null,
   DEVICE_ID            VARCHAR2(64),
   APP_ID               VARCHAR2(64),
   APP_VER_ID           VARCHAR2(64),
   CREATE_TIME          TIMESTAMP,
   UPDATE_TIME          TIMESTAMP
);

/*==============================================================*/
/* Table: ARES_DEVICE_BOUND_RELATION                            */
/*==============================================================*/
create table ARES_DEVICE_BOUND_RELATION 
(
   DEVICE_UUID          VARCHAR2(64)         not null,
   USER_ID              VARCHAR2(64)         not null,
   REGISTER_TIME        DATE,
   constraint PK_DEV_ID_USE_ID primary key (DEVICE_UUID, USER_ID)
);

comment on table ARES_DEVICE_BOUND_RELATION is
'设备用户绑定关系表';

comment on column ARES_DEVICE_BOUND_RELATION.DEVICE_UUID is
'设备UUID';

comment on column ARES_DEVICE_BOUND_RELATION.USER_ID is
'用户Id';

comment on column ARES_DEVICE_BOUND_RELATION.REGISTER_TIME is
'注册时间';

/*==============================================================*/
/* Table: ARES_DEVICE_INFO                                      */
/*==============================================================*/
create table ARES_DEVICE_INFO 
(
   DEVICE_UUID          VARCHAR2(64)         not null,
   DEVICE_NAME          VARCHAR2(255),
   DEVICE_NO            VARCHAR2(128),
   DEVICE_MODEL         VARCHAR2(255),
   DEVICE_SERIAL        VARCHAR2(64),
   MAC_ADDRESS          VARCHAR2(255),
   OS_TYPE              VARCHAR2(32),
   OS_VERSION           VARCHAR2(32),
   IS_ROOT              VARCHAR2(32),
   LOCK_FLAG            VARCHAR2(32),
   ERASE_FLAG           VARCHAR2(32),
   DEVICE_STATUS        VARCHAR2(32),
   REMARK               VARCHAR2(255),
   IPADDR               VARCHAR2(32),
   UPDATE_TIME          DATE,
   LOSE_FLAG            VARCHAR2(32),
   constraint P_PK_DEVICE_INFO primary key (DEVICE_UUID)
);

comment on table ARES_DEVICE_INFO is
'设备信息表';

comment on column ARES_DEVICE_INFO.DEVICE_UUID is
'设备UUID';

comment on column ARES_DEVICE_INFO.DEVICE_NAME is
'个人设备名称';

comment on column ARES_DEVICE_INFO.DEVICE_NO is
'设备编码或者标签';

comment on column ARES_DEVICE_INFO.DEVICE_MODEL is
'设备类型';

comment on column ARES_DEVICE_INFO.DEVICE_SERIAL is
'设备串号';

comment on column ARES_DEVICE_INFO.MAC_ADDRESS is
'设备MAC地址';

comment on column ARES_DEVICE_INFO.OS_TYPE is
'操作系统类型：IOS Android';

comment on column ARES_DEVICE_INFO.OS_VERSION is
'系统版本，2.6，4.3';

comment on column ARES_DEVICE_INFO.IS_ROOT is
'0：否
1：是';

comment on column ARES_DEVICE_INFO.LOCK_FLAG is
'0：无锁定
1：锁定';

comment on column ARES_DEVICE_INFO.ERASE_FLAG is
'0：无擦除
1：擦除';

comment on column ARES_DEVICE_INFO.DEVICE_STATUS is
'1:入库
2:领用
3:归还
4:注销
5:损坏
6:丢失
7:报废;';

comment on column ARES_DEVICE_INFO.REMARK is
'备注，描述信息';

comment on column ARES_DEVICE_INFO.IPADDR is
'最近访问IP';

comment on column ARES_DEVICE_INFO.UPDATE_TIME is
'最近访问时间';

comment on column ARES_DEVICE_INFO.LOSE_FLAG is
'0:正常，1：遗失';

/*==============================================================*/
/* Table: ARES_EVENT_CONFIG                                     */
/*==============================================================*/
create table ARES_EVENT_CONFIG 
(
   EVENT_ID             VARCHAR2(64)         not null,
   EVENT_NAME           VARCHAR2(200),
   LIMIT_COUNT          NUMBER(5,0)          default -1,
   EVENT_LEVEL          NUMBER(5,0),
   PARENT_ID            VARCHAR2(64),
   REMARKS              VARCHAR2(1024),
   constraint PK_EVENT_ID primary key (EVENT_ID)
);

comment on table ARES_EVENT_CONFIG is
'事件配置表';

comment on column ARES_EVENT_CONFIG.EVENT_ID is
'事件ID';

comment on column ARES_EVENT_CONFIG.EVENT_NAME is
'事件名称';

comment on column ARES_EVENT_CONFIG.LIMIT_COUNT is
'限制数量';

comment on column ARES_EVENT_CONFIG.EVENT_LEVEL is
'事件级别';

comment on column ARES_EVENT_CONFIG.PARENT_ID is
'父事件编号';

comment on column ARES_EVENT_CONFIG.REMARKS is
'备注';

/*==============================================================*/
/* Table: ARES_FILE_TAB                                         */
/*==============================================================*/
create table ARES_FILE_TAB 
(
   ID                   VARCHAR2(32)         not null,
   SERIAL_NO            VARCHAR2(64)         not null,
   FILE_NAME            VARCHAR2(64),
   FILE_SIZE            NUMBER(5,0),
   CREATE_TIME          TIMESTAMP            not null,
   constraint PK_ARES_FILE_TAB primary key (ID)
);

comment on table ARES_FILE_TAB is
'文件表';

comment on column ARES_FILE_TAB.ID is
'编号';

comment on column ARES_FILE_TAB.SERIAL_NO is
'序列号';

comment on column ARES_FILE_TAB.FILE_NAME is
'文件名';

comment on column ARES_FILE_TAB.FILE_SIZE is
'大小';

comment on column ARES_FILE_TAB.CREATE_TIME is
'时间';

/*==============================================================*/
/* Table: ARES_KEY_SEQUENCE                                     */
/*==============================================================*/
create table ARES_KEY_SEQUENCE 
(
   CODE                 VARCHAR2(64)         not null,
   VALUE                VARCHAR2(64),
   constraint SYS_C0010419 primary key (CODE)
);

comment on table ARES_KEY_SEQUENCE is
'序列表';

comment on column ARES_KEY_SEQUENCE.CODE is
'表名';

comment on column ARES_KEY_SEQUENCE.VALUE is
'序列当前值';

/*==============================================================*/
/* Table: ARES_LOG_INFO                                         */
/*==============================================================*/
create table ARES_LOG_INFO 
(
   LOG_ID               VARCHAR2(64)         not null,
   MSG_ID               VARCHAR2(64),
   EVENT_ID             VARCHAR2(64),
   USER_ID              VARCHAR2(64),
   DEVICE_ID            VARCHAR2(64),
   SERVER_ID            VARCHAR2(64),
   URL                  VARCHAR2(300),
   APP_TAG              VARCHAR2(50),
   LOG_LEVEL            VARCHAR2(20),
   LOG_TIME             VARCHAR2(20),
   LOG_DATA             VARCHAR2(2000),
   USED_TIME            VARCHAR2(100),
   SESSION_ID           VARCHAR2(64),
   CHANNEL_ID           VARCHAR2(64),
   APP_ID               VARCHAR2(64),
   APP_VERS             VARCHAR2(32),
   IP_ADDR              VARCHAR2(64),
   GPS                  VARCHAR2(64),
   PLACE                VARCHAR2(256),
   constraint PK_ARES_LOG_INFO primary key (LOG_ID)
);

/*==============================================================*/
/* Table: ARES_NOTE                                             */
/*==============================================================*/
create table ARES_NOTE 
(
   NOTE_ID              VARCHAR2(64)         not null,
   APP_ID               VARCHAR2(64),
   NOTE_TYP             VARCHAR2(1),
   NOTE_TITLE           VARCHAR2(128),
   NOTE_CONTENT         CLOB,
   SEND_BEGIN_TIME      TIMESTAMP            not null,
   SEND_END_TIME        TIMESTAMP,
   IMP_FLG              VARCHAR2(1),
   CREATE_TIME          TIMESTAMP            not null,
   UPDATE_TIME          TIMESTAMP            not null,
   AUDITOR_ID           VARCHAR2(64),
   AUDIT_INFO           VARCHAR2(1024),
   AUDIT_TIME           TIMESTAMP,
   AUDIT_STATUS         VARCHAR2(1)          not null,
   OPER_ID              VARCHAR2(64),
   NOTE_STATUS          VARCHAR2(1)          not null,
   constraint P_PK_ARES_NOTE primary key (NOTE_ID)
);

comment on table ARES_NOTE is
'资讯公告表';

comment on column ARES_NOTE.NOTE_ID is
'编号';

comment on column ARES_NOTE.APP_ID is
'应用编号';

comment on column ARES_NOTE.NOTE_TYP is
'公告类型';

comment on column ARES_NOTE.NOTE_TITLE is
'公告标题';

comment on column ARES_NOTE.NOTE_CONTENT is
'公告内容';

comment on column ARES_NOTE.SEND_BEGIN_TIME is
'上架时间';

comment on column ARES_NOTE.SEND_END_TIME is
'下架时间';

comment on column ARES_NOTE.IMP_FLG is
'重要度（1：一般，2：重要，3：非常重要）';

comment on column ARES_NOTE.CREATE_TIME is
'创建时间';

comment on column ARES_NOTE.UPDATE_TIME is
'修改时间';

comment on column ARES_NOTE.AUDITOR_ID is
'审核者';

comment on column ARES_NOTE.AUDIT_INFO is
'审核信息';

comment on column ARES_NOTE.AUDIT_TIME is
'审核时间';

comment on column ARES_NOTE.AUDIT_STATUS is
'审核状态（0 ：未审核，
1：审核通过，
2：审核未通过）';

comment on column ARES_NOTE.OPER_ID is
'操作者';

comment on column ARES_NOTE.NOTE_STATUS is
'消息状态（0：未发布，1：已发布）';

/*==============================================================*/
/* Table: ARES_SESSION                                          */
/*==============================================================*/
create table ARES_SESSION 
(
   SESSION_ID           VARCHAR2(64)         not null,
   CREATE_TIME          TIMESTAMP,
   VISIT_TIME           TIMESTAMP,
   INVALID_TIME         TIMESTAMP,
   MSG_ID               VARCHAR2(64),
   KEY                  VARCHAR2(1024),
   EVENT_ID             VARCHAR2(64),
   USER_ID              VARCHAR2(64),
   DEVICE_ID            VARCHAR2(64),
   SERVER_IP            VARCHAR2(15),
   AUTH_STATUS          VARCHAR2(4),
   DATA                 VARCHAR2(4000),
   VERSION              NUMBER(5,0)          default 1 not null,
   MSGID_SET            VARCHAR2(768),
   ERROR_ID             VARCHAR2(32),
   ERROR_MSG            VARCHAR2(512),
   THIRD_SESSION_ID     VARCHAR2(64),
   THIRD_ACCESS_TIME    TIMESTAMP,
   constraint PK_MSC_SESSION primary key (SESSION_ID)
);

comment on table ARES_SESSION is
'会话数据表';

comment on column ARES_SESSION.SESSION_ID is
'会话标识';

comment on column ARES_SESSION.CREATE_TIME is
'创建时间';

comment on column ARES_SESSION.VISIT_TIME is
'最后访问时间';

comment on column ARES_SESSION.INVALID_TIME is
'失效时间';

comment on column ARES_SESSION.MSG_ID is
'消息ID';

comment on column ARES_SESSION.KEY is
'加密后的密钥';

comment on column ARES_SESSION.EVENT_ID is
'事件ID';

comment on column ARES_SESSION.USER_ID is
'用户标识';

comment on column ARES_SESSION.DEVICE_ID is
'设备标识';

comment on column ARES_SESSION.SERVER_IP is
'服务器标识';

comment on column ARES_SESSION.AUTH_STATUS is
'用户认证状态';

comment on column ARES_SESSION.DATA is
'会话数据';

comment on column ARES_SESSION.VERSION is
'记录版本';

/*==============================================================*/
/* Table: ARES_SESSION_HIS                                      */
/*==============================================================*/
create table ARES_SESSION_HIS 
(
   SESSION_ID           VARCHAR2(64)         not null,
   CREATE_TIME          TIMESTAMP,
   VISIT_TIME           TIMESTAMP,
   INVALID_TIME         TIMESTAMP,
   MSG_ID               VARCHAR2(64),
   KEY                  VARCHAR2(256),
   EVENT_ID             VARCHAR2(64),
   USER_ID              VARCHAR2(64),
   DEVICE_ID            VARCHAR2(64),
   SERVER_IP            VARCHAR2(15),
   AUTH_STATUS          VARCHAR2(4),
   DATA                 VARCHAR2(4000),
   VERSION              NUMBER(5,0)          default 1 not null,
   MSGID_SET            VARCHAR2(256),
   ERROR_ID             VARCHAR2(32),
   ERROR_MSG            VARCHAR2(512),
   THIRD_SESSION_ID     VARCHAR2(64),
   THIRD_ACCESS_TIME    TIMESTAMP
);

/*==============================================================*/
/* Table: ARES_SESSION_LOG                                      */
/*==============================================================*/
create table ARES_SESSION_LOG 
(
   SESS_LOG_ID          VARCHAR2(64)         not null,
   USER_ID              VARCHAR2(64),
   DEVICE_ID            VARCHAR2(64),
   APP_START_DTIME      TIMESTAMP,
   APP_STOP_DTIME       TIMESTAMP,
   APP_ID               VARCHAR2(64),
   APP_VER_ID           VARCHAR2(64),
   POS_X                NUMBER(8,2),
   POS_Y                NUMBER(8,2),
   DEVICE_MODEL         VARCHAR2(100),
   DEVICE_SYSTEM        VARCHAR2(100),
   VERSION              NUMBER(8,0)          default 0,
   SESSION_ID           VARCHAR2(64),
   SESSION_STATUS       VARCHAR2(1)          default '0',
   constraint PK_SESSION_LOG primary key (SESS_LOG_ID)
);

comment on table ARES_SESSION_LOG is
'会话日志';

comment on column ARES_SESSION_LOG.SESS_LOG_ID is
'会话日志标识';

comment on column ARES_SESSION_LOG.USER_ID is
'用户标识';

comment on column ARES_SESSION_LOG.DEVICE_ID is
'设备标识';

comment on column ARES_SESSION_LOG.APP_START_DTIME is
'应用启动时间';

comment on column ARES_SESSION_LOG.APP_STOP_DTIME is
'应用结束时间';

comment on column ARES_SESSION_LOG.APP_ID is
'应用标识';

comment on column ARES_SESSION_LOG.APP_VER_ID is
'应用版本标识';

comment on column ARES_SESSION_LOG.POS_X is
'位置X';

comment on column ARES_SESSION_LOG.POS_Y is
'位置Y';

comment on column ARES_SESSION_LOG.DEVICE_MODEL is
'DEVICE_MODEL';

comment on column ARES_SESSION_LOG.DEVICE_SYSTEM is
'DEVICE_SYSTEM';

comment on column ARES_SESSION_LOG.VERSION is
'VERSION';

comment on column ARES_SESSION_LOG.SESSION_ID is
'SESSION_ID';

comment on column ARES_SESSION_LOG.SESSION_STATUS is
'SESSION_STATUS';

/*==============================================================*/
/* Table: DEVICE_CRASH_LOG                                      */
/*==============================================================*/
create table DEVICE_CRASH_LOG 
(
   LOG_ID               VARCHAR2(64)         not null,
   DEVICE_ID            VARCHAR2(64),
   DEVICE_MODEL         VARCHAR2(16),
   DEVICE_SYSTEM        VARCHAR2(16),
   APP_ID               VARCHAR2(16),
   APP_VERS_NO          VARCHAR2(8),
   USER_ID              VARCHAR2(32),
   SESSION_ID           VARCHAR2(32),
   LOG_LEVEL            VARCHAR2(8),
   LOG_TIME             VARCHAR2(32),
   ERROR_INFO           CLOB,
   CREATE_TIME          VARCHAR2(32),
   constraint PK_DEVICE_CRASH_LOG primary key (LOG_ID)
);

comment on column DEVICE_CRASH_LOG.LOG_ID is
'主键标识';

comment on column DEVICE_CRASH_LOG.DEVICE_ID is
'设备Id';

comment on column DEVICE_CRASH_LOG.DEVICE_MODEL is
'设备型号';

comment on column DEVICE_CRASH_LOG.DEVICE_SYSTEM is
'系统类型+版本';

comment on column DEVICE_CRASH_LOG.APP_ID is
'应用ID';

comment on column DEVICE_CRASH_LOG.APP_VERS_NO is
'版本编号';

comment on column DEVICE_CRASH_LOG.USER_ID is
'用户Id';

comment on column DEVICE_CRASH_LOG.SESSION_ID is
'会话ID';

comment on column DEVICE_CRASH_LOG.LOG_LEVEL is
'日志级别';

comment on column DEVICE_CRASH_LOG.LOG_TIME is
'日志记录时间';

comment on column DEVICE_CRASH_LOG.ERROR_INFO is
'错误堆栈';

comment on column DEVICE_CRASH_LOG.CREATE_TIME is
'入库时间';

/*==============================================================*/
/* Table: MGG_TRANS_LOG                                         */
/*==============================================================*/
create table MGG_TRANS_LOG 
(
   TRANS_LOG_SEQ        VARCHAR2(60)         not null,
   SESSION_ID           VARCHAR2(32),
   TRAN_DATE            VARCHAR2(10),
   TRAN_TIME            VARCHAR2(10),
   LGN_ID               VARCHAR2(20),
   TRANS_CODE           VARCHAR2(256),
   DEVICE_ID            VARCHAR2(64),
   MSG                  VARCHAR2(200),
   OTH_COMM             VARCHAR2(500),
   STATUS               VARCHAR2(8),
   TRANS_COST           VARCHAR2(64),
   constraint PK_TRANS_LOG_SEQ_ID primary key (TRANS_LOG_SEQ)
);

comment on table MGG_TRANS_LOG is
'通用交易日志表';

comment on column MGG_TRANS_LOG.TRANS_LOG_SEQ is
'日志Id';

comment on column MGG_TRANS_LOG.SESSION_ID is
'会话Id';

comment on column MGG_TRANS_LOG.TRAN_DATE is
'交易日期';

comment on column MGG_TRANS_LOG.TRAN_TIME is
'交易时间';

comment on column MGG_TRANS_LOG.LGN_ID is
'登陆用户编号';

comment on column MGG_TRANS_LOG.TRANS_CODE is
'交易编码';

comment on column MGG_TRANS_LOG.DEVICE_ID is
'设备Id';

comment on column MGG_TRANS_LOG.MSG is
'返回信息';

comment on column MGG_TRANS_LOG.OTH_COMM is
'认证信息';

comment on column MGG_TRANS_LOG.STATUS is
'返回标识';

comment on column MGG_TRANS_LOG.TRANS_COST is
'交易耗时';

/*==============================================================*/
/* Table: MGJ_BRANCH_CITY                                       */
/*==============================================================*/
create table MGJ_BRANCH_CITY 
(
   CITY_ID              VARCHAR2(64)         not null,
   PROV_ID              VARCHAR2(64),
   CITY_NAME            VARCHAR2(100),
   constraint SYS_C009597 primary key (CITY_ID)
);

comment on table MGJ_BRANCH_CITY is
'网点城市表';

comment on column MGJ_BRANCH_CITY.CITY_ID is
'城市编号';

comment on column MGJ_BRANCH_CITY.PROV_ID is
'省份编号';

comment on column MGJ_BRANCH_CITY.CITY_NAME is
'城市名称';

/*==============================================================*/
/* Table: MGJ_BRANCH_INFO                                       */
/*==============================================================*/
create table MGJ_BRANCH_INFO 
(
   BRCH_ID              VARCHAR2(64)         not null,
   PROV_ID              VARCHAR2(64),
   CITY_ID              VARCHAR2(64),
   TOWN_ID              VARCHAR2(64),
   BRCH_TYPE            VARCHAR2(1),
   BRCH_NAME            VARCHAR2(200),
   BRCH_ADDR            VARCHAR2(300),
   BRCH_SERV            VARCHAR2(300),
   BRCH_SERV1           VARCHAR2(300),
   BRCH_SERV2           VARCHAR2(300),
   BRCH_POST            VARCHAR2(6),
   BRCH_TRAF            VARCHAR2(300),
   BRCH_TEL1            VARCHAR2(20),
   BRCH_TEL2            VARCHAR2(20),
   VALID_FLAG           VARCHAR2(1),
   POS_X                NUMBER(12,8),
   POS_Y                NUMBER(12,8),
   PUB_DATE             TIMESTAMP,
   EDITOR_UID           VARCHAR2(64),
   EDITOR_DATE          TIMESTAMP,
   CHK_UID              VARCHAR2(64),
   CHK_DATE             TIMESTAMP,
   ATM_TYPE             VARCHAR2(60),
   constraint SYS_C009595 primary key (BRCH_ID)
);

comment on table MGJ_BRANCH_INFO is
'网点信息表';

comment on column MGJ_BRANCH_INFO.BRCH_ID is
'网点编号';

comment on column MGJ_BRANCH_INFO.PROV_ID is
'省份编号';

comment on column MGJ_BRANCH_INFO.CITY_ID is
'城市编号';

comment on column MGJ_BRANCH_INFO.TOWN_ID is
'城镇编号';

comment on column MGJ_BRANCH_INFO.BRCH_TYPE is
'网点类型
0-综合网点
1-ATM';

comment on column MGJ_BRANCH_INFO.BRCH_NAME is
'网点名称';

comment on column MGJ_BRANCH_INFO.BRCH_ADDR is
'网点地址';

comment on column MGJ_BRANCH_INFO.BRCH_SERV is
'对私营业时间';

comment on column MGJ_BRANCH_INFO.BRCH_SERV1 is
'对公营业时间';

comment on column MGJ_BRANCH_INFO.BRCH_SERV2 is
'周末营业时间';

comment on column MGJ_BRANCH_INFO.BRCH_POST is
'邮编';

comment on column MGJ_BRANCH_INFO.BRCH_TRAF is
'交通路线';

comment on column MGJ_BRANCH_INFO.BRCH_TEL1 is
'电话1';

comment on column MGJ_BRANCH_INFO.BRCH_TEL2 is
'电话2';

comment on column MGJ_BRANCH_INFO.VALID_FLAG is
'有效状态 
0-无效
1-有效 可查询';

comment on column MGJ_BRANCH_INFO.POS_X is
'坐标X';

comment on column MGJ_BRANCH_INFO.POS_Y is
'坐标Y';

comment on column MGJ_BRANCH_INFO.PUB_DATE is
'发布日期';

comment on column MGJ_BRANCH_INFO.EDITOR_UID is
'编辑人';

comment on column MGJ_BRANCH_INFO.EDITOR_DATE is
'编辑日期';

comment on column MGJ_BRANCH_INFO.CHK_UID is
'审核人';

comment on column MGJ_BRANCH_INFO.CHK_DATE is
'审核日期';

comment on column MGJ_BRANCH_INFO.ATM_TYPE is
'ATM类型';

/*==============================================================*/
/* Table: MGJ_BRANCH_PROVINCE                                   */
/*==============================================================*/
create table MGJ_BRANCH_PROVINCE 
(
   PROV_ID              VARCHAR2(64)         not null,
   PROV_NAME            VARCHAR2(100),
   constraint SYS_C009596 primary key (PROV_ID)
);

comment on table MGJ_BRANCH_PROVINCE is
'网点省份表';

comment on column MGJ_BRANCH_PROVINCE.PROV_ID is
'省份编号';

comment on column MGJ_BRANCH_PROVINCE.PROV_NAME is
'省份名称';

/*==============================================================*/
/* Table: MGJ_BRANCH_TOWN                                       */
/*==============================================================*/
create table MGJ_BRANCH_TOWN 
(
   TOWN_ID              VARCHAR2(64)         not null,
   CITY_ID              VARCHAR2(64),
   TOWN_NAME            VARCHAR2(100),
   constraint SYS_C009598 primary key (TOWN_ID)
);

comment on table MGJ_BRANCH_TOWN is
'网点区县表';

comment on column MGJ_BRANCH_TOWN.TOWN_ID is
'区县编号';

comment on column MGJ_BRANCH_TOWN.CITY_ID is
'城市编号';

comment on column MGJ_BRANCH_TOWN.TOWN_NAME is
'区县名称';

/*==============================================================*/
/* Table: MZJ_BANNER_DATA                                       */
/*==============================================================*/
create table MZJ_BANNER_DATA 
(
   BANNER_ID            VARCHAR2(64)         not null,
   BANNER_PIC           VARCHAR2(64),
   FILE_ID              VARCHAR2(64),
   BANNER_NAME          VARCHAR2(100),
   ORGAN_LIMIT          VARCHAR2(64),
   BANNER_LVL           VARCHAR2(100),
   BANNER_ORDE          NUMBER(5,0),
   VAILD_DATE           TIMESTAMP,
   EDITOR               VARCHAR2(64),
   EDITOR_TIME          TIMESTAMP,
   STATUS               VARCHAR2(10),
   DEL_FLAG             VARCHAR2(1),
   constraint SYS_C0010072 primary key (BANNER_ID)
);

comment on table MZJ_BANNER_DATA is
'广告';

comment on column MZJ_BANNER_DATA.BANNER_ID is
'BANNER_ID';

comment on column MZJ_BANNER_DATA.BANNER_PIC is
'BANNER_PIC';

comment on column MZJ_BANNER_DATA.FILE_ID is
'FILE_ID';

comment on column MZJ_BANNER_DATA.BANNER_NAME is
'BANNER_NAME';

comment on column MZJ_BANNER_DATA.ORGAN_LIMIT is
'ORGAN_LIMIT';

comment on column MZJ_BANNER_DATA.BANNER_LVL is
'BANNER_LVL';

comment on column MZJ_BANNER_DATA.BANNER_ORDE is
'BANNER_ORDE';

comment on column MZJ_BANNER_DATA.VAILD_DATE is
'VAILD_DATE';

comment on column MZJ_BANNER_DATA.EDITOR is
'EDITOR';

comment on column MZJ_BANNER_DATA.EDITOR_TIME is
'EDITOR_TIME';

comment on column MZJ_BANNER_DATA.STATUS is
'STATUS';

comment on column MZJ_BANNER_DATA.DEL_FLAG is
'DEL_FLAG';

/*==============================================================*/
/* Table: MZJ_FILES_DATA                                        */
/*==============================================================*/
create table MZJ_FILES_DATA 
(
   FILE_ID              VARCHAR2(64)         not null,
   FILE_CATA            VARCHAR2(1),
   FILE_NAME            VARCHAR2(100),
   FILE_TYPE            VARCHAR2(2),
   FILE_SIZE            VARCHAR2(10),
   FILE_ADDR            VARCHAR2(100),
   FILE_VALID_DATE      TIMESTAMP            not null,
   FILE_KEYS            VARCHAR2(300),
   EDITOR               VARCHAR2(64),
   EDITOR_TIME          TIMESTAMP            not null,
   FILE_ADDR_CN         VARCHAR2(100),
   ORGAN_LIMIT          VARCHAR2(64),
   DEL_FLAG             VARCHAR2(1)          default '0',
   constraint SYS_C0010070 primary key (FILE_ID)
);

comment on table MZJ_FILES_DATA is
'资源';

comment on column MZJ_FILES_DATA.FILE_ID is
'FILE_ID';

comment on column MZJ_FILES_DATA.FILE_CATA is
'FILE_CATA';

comment on column MZJ_FILES_DATA.FILE_NAME is
'FILE_NAME';

comment on column MZJ_FILES_DATA.FILE_TYPE is
'FILE_TYPE';

comment on column MZJ_FILES_DATA.FILE_SIZE is
'FILE_SIZE';

comment on column MZJ_FILES_DATA.FILE_ADDR is
'FILE_ADDR';

comment on column MZJ_FILES_DATA.FILE_VALID_DATE is
'FILE_VALID_DATE';

comment on column MZJ_FILES_DATA.FILE_KEYS is
'FILE_KEYS';

comment on column MZJ_FILES_DATA.EDITOR is
'EDITOR';

comment on column MZJ_FILES_DATA.EDITOR_TIME is
'EDITOR_TIME';

comment on column MZJ_FILES_DATA.FILE_ADDR_CN is
'FILE_ADDR_CN';

comment on column MZJ_FILES_DATA.ORGAN_LIMIT is
'ORGAN_LIMIT';

comment on column MZJ_FILES_DATA.DEL_FLAG is
'DEL_FLAG';

/*==============================================================*/
/* Table: MZJ_PROPA_DATA                                        */
/*==============================================================*/
create table MZJ_PROPA_DATA 
(
   PROPA_ID             VARCHAR2(64)         not null,
   FILE_ID              VARCHAR2(64),
   PROPA_NAME           VARCHAR2(100),
   PROPA_TYPE           VARCHAR2(10),
   PROPA_PIC            VARCHAR2(100),
   PROPA_LVL            VARCHAR2(10),
   PROPA_ORDE           NUMBER(5,0),
   VAILD_DATE           TIMESTAMP,
   ORGAN_LIMIT          VARCHAR2(64),
   EDITOR               VARCHAR2(64),
   EDITOR_TIME          TIMESTAMP,
   STATUS               VARCHAR2(20),
   PRO_BUSI_TYPE        VARCHAR2(10),
   constraint SYS_C0010071 primary key (PROPA_ID)
);

comment on table MZJ_PROPA_DATA is
'展架';

comment on column MZJ_PROPA_DATA.PROPA_ID is
'PROPA_ID';

comment on column MZJ_PROPA_DATA.FILE_ID is
'FILE_ID';

comment on column MZJ_PROPA_DATA.PROPA_NAME is
'PROPA_NAME';

comment on column MZJ_PROPA_DATA.PROPA_TYPE is
'PROPA_TYPE';

comment on column MZJ_PROPA_DATA.PROPA_PIC is
'PROPA_PIC';

comment on column MZJ_PROPA_DATA.PROPA_LVL is
'PROPA_LVL';

comment on column MZJ_PROPA_DATA.PROPA_ORDE is
'PROPA_ORDE';

comment on column MZJ_PROPA_DATA.VAILD_DATE is
'VAILD_DATE';

comment on column MZJ_PROPA_DATA.ORGAN_LIMIT is
'ORGAN_LIMIT';

comment on column MZJ_PROPA_DATA.EDITOR is
'EDITOR';

comment on column MZJ_PROPA_DATA.EDITOR_TIME is
'EDITOR_TIME';

comment on column MZJ_PROPA_DATA.STATUS is
'STATUS';

comment on column MZJ_PROPA_DATA.PRO_BUSI_TYPE is
'PRO_BUSI_TYPE';

/*==============================================================*/
/* Table: SYS_AREA                                              */
/*==============================================================*/
create table SYS_AREA 
(
   ID                   VARCHAR2(64)         not null,
   PARENT_ID            VARCHAR2(64)         not null,
   PARENT_IDS           VARCHAR2(2000)       not null,
   CODE                 VARCHAR2(64),
   NAME                 VARCHAR2(100)        not null,
   TYPE                 VARCHAR2(1),
   CREATE_BY            VARCHAR2(64),
   CREATE_DATE          TIMESTAMP,
   UPDATE_BY            VARCHAR2(64),
   UPDATE_DATE          TIMESTAMP,
   REMARKS              VARCHAR2(255),
   DEL_FLAG             VARCHAR2(1)          default '0' not null,
   constraint SYS_C009133 primary key (ID)
);

comment on table SYS_AREA is
'区域表';

comment on column SYS_AREA.ID is
'编号';

comment on column SYS_AREA.PARENT_ID is
'父级编号';

comment on column SYS_AREA.PARENT_IDS is
'所有父级编号';

comment on column SYS_AREA.CODE is
'区域编码';

comment on column SYS_AREA.NAME is
'区域名称';

comment on column SYS_AREA.TYPE is
'区域类型';

comment on column SYS_AREA.CREATE_BY is
'创建者';

comment on column SYS_AREA.CREATE_DATE is
'创建时间';

comment on column SYS_AREA.UPDATE_BY is
'更新者';

comment on column SYS_AREA.UPDATE_DATE is
'更新时间';

comment on column SYS_AREA.REMARKS is
'备注信息';

comment on column SYS_AREA.DEL_FLAG is
'删除标记';

/*==============================================================*/
/* Index: SYS_AREA_DEL_FLAG                                     */
/*==============================================================*/
create index SYS_AREA_DEL_FLAG on SYS_AREA (
   DEL_FLAG ASC
);

/*==============================================================*/
/* Index: SYS_AREA_PARENT_ID                                    */
/*==============================================================*/
create index SYS_AREA_PARENT_ID on SYS_AREA (
   PARENT_ID ASC
);

/*==============================================================*/
/* Index: SYS_AREA_PARENT_IDS                                   */
/*==============================================================*/
create index SYS_AREA_PARENT_IDS on SYS_AREA (
   PARENT_IDS ASC
);

/*==============================================================*/
/* Table: SYS_CHECK_CONFIG                                      */
/*==============================================================*/
create table SYS_CHECK_CONFIG 
(
   CONFIG_ID            VARCHAR2(64)         not null,
   SERVICE_URL          VARCHAR2(255),
   MODEL_NAME           VARCHAR2(64),
   ACTION               VARCHAR2(32),
   CLASS_NAME           VARCHAR2(64),
   CLASS_FULL_PATH      VARCHAR2(1024),
   IS_CHECK             VARCHAR2(32),
   ACTION_NAME          VARCHAR2(64),
   OBJECT_NAME          VARCHAR2(32),
   constraint PK_SYS_CHECK_CFG primary key (CONFIG_ID)
);

comment on table SYS_CHECK_CONFIG is
'审核功能配置表';

comment on column SYS_CHECK_CONFIG.CONFIG_ID is
'主键';

comment on column SYS_CHECK_CONFIG.SERVICE_URL is
'服务URL';

comment on column SYS_CHECK_CONFIG.MODEL_NAME is
'模块名称';

comment on column SYS_CHECK_CONFIG.ACTION is
'1：新增
2：修改
3：删除';

comment on column SYS_CHECK_CONFIG.CLASS_NAME is
'类名';

comment on column SYS_CHECK_CONFIG.CLASS_FULL_PATH is
'类路径';

comment on column SYS_CHECK_CONFIG.IS_CHECK is
'1：需要审核
0：不需要审核';

comment on column SYS_CHECK_CONFIG.ACTION_NAME is
'功能名称';

comment on column SYS_CHECK_CONFIG.OBJECT_NAME is
'对象名称';

/*==============================================================*/
/* Table: SYS_CHECK_DETAIL                                      */
/*==============================================================*/
create table SYS_CHECK_DETAIL 
(
   CHECK_DETAIL_ID      VARCHAR2(64)         not null,
   ENTITY_DAO_PATH      VARCHAR2(1024),
   ENTITY_ID            VARCHAR2(2048),
   PARAM                CLOB,
   PARAM_TYPE           VARCHAR2(1024),
   OLD_VALUE            CLOB,
   MEMO                 VARCHAR2(1024),
   STATUS               VARCHAR2(32),
   CHECK_ID             VARCHAR2(32),
   METHOD_NAME          VARCHAR2(128),
   ORG_PARAM_TYPE       VARCHAR2(1024),
   ENTITY_NAME          VARCHAR2(2048),
   ACTION_NAME          VARCHAR2(32),
   OBJECT_NAME          VARCHAR2(32),
   constraint P_PK_CHECK_DETAIL primary key (CHECK_DETAIL_ID)
);

comment on table SYS_CHECK_DETAIL is
'审核详情表';

comment on column SYS_CHECK_DETAIL.CHECK_DETAIL_ID is
'主键';

comment on column SYS_CHECK_DETAIL.ENTITY_DAO_PATH is
'持久化DAO路径';

comment on column SYS_CHECK_DETAIL.ENTITY_ID is
'实体主键';

comment on column SYS_CHECK_DETAIL.PARAM is
'参数';

comment on column SYS_CHECK_DETAIL.PARAM_TYPE is
'运行参数类型';

comment on column SYS_CHECK_DETAIL.OLD_VALUE is
'实体老值';

comment on column SYS_CHECK_DETAIL.MEMO is
'描述';

comment on column SYS_CHECK_DETAIL.STATUS is
'1：成功
0：失败';

comment on column SYS_CHECK_DETAIL.CHECK_ID is
'所属审核';

comment on column SYS_CHECK_DETAIL.METHOD_NAME is
'方法名称';

comment on column SYS_CHECK_DETAIL.ORG_PARAM_TYPE is
'定义参数类型';

comment on column SYS_CHECK_DETAIL.ENTITY_NAME is
'实体名称';

comment on column SYS_CHECK_DETAIL.ACTION_NAME is
'操作类型';

comment on column SYS_CHECK_DETAIL.OBJECT_NAME is
'对象名称';

/*==============================================================*/
/* Table: SYS_CHECK_INFO                                        */
/*==============================================================*/
create table SYS_CHECK_INFO 
(
   CHECK_ID             VARCHAR2(64)         not null,
   CONFIG_ID            VARCHAR2(64),
   PARAM                VARCHAR2(2048),
   STATUS               VARCHAR2(32),
   CREATE_DATE          DATE,
   CREATOR              VARCHAR2(32),
   CHECK_DATE           DATE,
   CHECKER              VARCHAR2(32),
   CHECK_INFO           VARCHAR2(2048),
   constraint PK_SYS_CHECK_INFO primary key (CHECK_ID)
);

comment on table SYS_CHECK_INFO is
'审核表';

comment on column SYS_CHECK_INFO.CHECK_ID is
'主键';

comment on column SYS_CHECK_INFO.CONFIG_ID is
'适配ID，审核配置主键';

comment on column SYS_CHECK_INFO.PARAM is
'参数';

comment on column SYS_CHECK_INFO.STATUS is
'1：待审核
2：审核通过
3：审核不通过';

comment on column SYS_CHECK_INFO.CREATE_DATE is
'创建时间';

comment on column SYS_CHECK_INFO.CREATOR is
'创建人';

comment on column SYS_CHECK_INFO.CHECK_DATE is
'审核时间';

comment on column SYS_CHECK_INFO.CHECKER is
'审核人';

comment on column SYS_CHECK_INFO.CHECK_INFO is
'审核信息';

/*==============================================================*/
/* Index: SYS_CHECK_INFO_CONFIG_ID                              */
/*==============================================================*/
create index SYS_CHECK_INFO_CONFIG_ID on SYS_CHECK_INFO (
   CONFIG_ID ASC
);

/*==============================================================*/
/* Index: SYS_CHECK_INFO_STATUS                                 */
/*==============================================================*/
create index SYS_CHECK_INFO_STATUS on SYS_CHECK_INFO (
   STATUS ASC
);

/*==============================================================*/
/* Table: SYS_DICT                                              */
/*==============================================================*/
create table SYS_DICT 
(
   ID                   VARCHAR2(64)         not null,
   LABEL                VARCHAR2(100)        not null,
   VALUE                VARCHAR2(100)        not null,
   TYPE                 VARCHAR2(100)        not null,
   DESCRIPTION          VARCHAR2(100)        not null,
   SORT                 NUMBER(10,0)         not null,
   CREATE_BY            VARCHAR2(64),
   CREATE_DATE          TIMESTAMP,
   UPDATE_BY            VARCHAR2(64),
   UPDATE_DATE          TIMESTAMP,
   REMARKS              VARCHAR2(255),
   DEL_FLAG             VARCHAR2(1)          default '0' not null,
   constraint SYS_C009136 primary key (ID)
);

comment on table SYS_DICT is
'字典表';

comment on column SYS_DICT.ID is
'编号';

comment on column SYS_DICT.LABEL is
'标签名';

comment on column SYS_DICT.VALUE is
'数据值';

comment on column SYS_DICT.TYPE is
'类型';

comment on column SYS_DICT.DESCRIPTION is
'描述';

comment on column SYS_DICT.SORT is
'排序（升序）';

comment on column SYS_DICT.CREATE_BY is
'创建者';

comment on column SYS_DICT.CREATE_DATE is
'创建时间';

comment on column SYS_DICT.UPDATE_BY is
'更新者';

comment on column SYS_DICT.UPDATE_DATE is
'更新时间';

comment on column SYS_DICT.REMARKS is
'备注信息';

comment on column SYS_DICT.DEL_FLAG is
'删除标记';

/*==============================================================*/
/* Index: SYS_DICT_DEL_FLAG                                     */
/*==============================================================*/
create index SYS_DICT_DEL_FLAG on SYS_DICT (
   DEL_FLAG ASC
);

/*==============================================================*/
/* Index: SYS_DICT_LABEL                                        */
/*==============================================================*/
create index SYS_DICT_LABEL on SYS_DICT (
   LABEL ASC
);

/*==============================================================*/
/* Index: SYS_DICT_VALUE                                        */
/*==============================================================*/
create index SYS_DICT_VALUE on SYS_DICT (
   VALUE ASC
);

/*==============================================================*/
/* Table: SYS_ENTITY_ATTRIBUTE                                  */
/*==============================================================*/
create table SYS_ENTITY_ATTRIBUTE 
(
   ATTRIBUTE_ID         VARCHAR2(32)         not null,
   TABLE_NAME           VARCHAR2(32),
   FIELD_NAME           VARCHAR2(64),
   CLASS_NAME           VARCHAR2(32),
   PROPERTY_NAME        VARCHAR2(64),
   PROPERTY_MEMO        VARCHAR2(255),
   ORDER_INDEX          VARCHAR2(32),
   IS_SHOW              VARCHAR2(32),
   IS_PK                VARCHAR2(32),
   constraint P_PK_ENTITY_ATTRIB primary key (ATTRIBUTE_ID)
);

comment on table SYS_ENTITY_ATTRIBUTE is
'实体属性配置表';

comment on column SYS_ENTITY_ATTRIBUTE.ATTRIBUTE_ID is
'主键';

comment on column SYS_ENTITY_ATTRIBUTE.TABLE_NAME is
'表名';

comment on column SYS_ENTITY_ATTRIBUTE.FIELD_NAME is
'字段名';

comment on column SYS_ENTITY_ATTRIBUTE.CLASS_NAME is
'类名';

comment on column SYS_ENTITY_ATTRIBUTE.PROPERTY_NAME is
'属性名';

comment on column SYS_ENTITY_ATTRIBUTE.PROPERTY_MEMO is
'属性描述';

comment on column SYS_ENTITY_ATTRIBUTE.ORDER_INDEX is
'顺序';

comment on column SYS_ENTITY_ATTRIBUTE.IS_SHOW is
'0：不显示
1：显示';

comment on column SYS_ENTITY_ATTRIBUTE.IS_PK is
'0：其他属性
1：主键
2：名称';

/*==============================================================*/
/* Table: SYS_LOG                                               */
/*==============================================================*/
create table SYS_LOG 
(
   ID                   VARCHAR2(64)         not null,
   TYPE                 VARCHAR2(1),
   CREATE_BY            VARCHAR2(64),
   CREATE_DATE          TIMESTAMP,
   REMOTE_ADDR          VARCHAR2(15),
   USER_AGENT           VARCHAR2(255),
   REQUEST_URI          VARCHAR2(255),
   METHOD               VARCHAR2(5),
   PARAMS               CLOB,
   EXCEPTION            CLOB,
   constraint SYS_C009441 primary key (ID)
);

comment on table SYS_LOG is
'日志表';

comment on column SYS_LOG.ID is
'编号';

comment on column SYS_LOG.TYPE is
'日志类型';

comment on column SYS_LOG.CREATE_BY is
'创建者';

comment on column SYS_LOG.CREATE_DATE is
'创建时间';

comment on column SYS_LOG.REMOTE_ADDR is
'操作IP地址';

comment on column SYS_LOG.USER_AGENT is
'用户代理';

comment on column SYS_LOG.REQUEST_URI is
'请求URI';

comment on column SYS_LOG.METHOD is
'操作方式';

comment on column SYS_LOG.PARAMS is
'操作提交的数据';

comment on column SYS_LOG.EXCEPTION is
'异常信息';

/*==============================================================*/
/* Table: SYS_MENU                                              */
/*==============================================================*/
create table SYS_MENU 
(
   ID                   VARCHAR2(64)         not null,
   PARENT_ID            VARCHAR2(64)         not null,
   PARENT_IDS           VARCHAR2(2000)       not null,
   NAME                 VARCHAR2(100)        not null,
   HREF                 VARCHAR2(255),
   TARGET               VARCHAR2(20),
   ICON                 VARCHAR2(100),
   SORT                 NUMBER(10,0)         not null,
   IS_SHOW              VARCHAR2(1)          not null,
   IS_ACTIVITI          VARCHAR2(1),
   PERMISSION           VARCHAR2(200),
   CREATE_BY            VARCHAR2(64),
   CREATE_DATE          TIMESTAMP,
   UPDATE_BY            VARCHAR2(64),
   UPDATE_DATE          TIMESTAMP,
   REMARKS              VARCHAR2(255),
   DEL_FLAG             VARCHAR2(1)          default '0' not null,
   constraint SYS_C009138 primary key (ID)
);

comment on table SYS_MENU is
'菜单表';

comment on column SYS_MENU.ID is
'编号';

comment on column SYS_MENU.PARENT_ID is
'父级编号';

comment on column SYS_MENU.PARENT_IDS is
'所有父级编号';

comment on column SYS_MENU.NAME is
'菜单名称';

comment on column SYS_MENU.HREF is
'链接';

comment on column SYS_MENU.TARGET is
'目标';

comment on column SYS_MENU.ICON is
'图标';

comment on column SYS_MENU.SORT is
'排序（升序）';

comment on column SYS_MENU.IS_SHOW is
'是否在菜单中显示';

comment on column SYS_MENU.IS_ACTIVITI is
'是否同步工作流';

comment on column SYS_MENU.PERMISSION is
'权限标识';

comment on column SYS_MENU.CREATE_BY is
'创建者';

comment on column SYS_MENU.CREATE_DATE is
'创建时间';

comment on column SYS_MENU.UPDATE_BY is
'更新者';

comment on column SYS_MENU.UPDATE_DATE is
'更新时间';

comment on column SYS_MENU.REMARKS is
'备注信息';

comment on column SYS_MENU.DEL_FLAG is
'删除标记';

/*==============================================================*/
/* Index: SYS_MENU_DEL_FLAG                                     */
/*==============================================================*/
create index SYS_MENU_DEL_FLAG on SYS_MENU (
   DEL_FLAG ASC
);

/*==============================================================*/
/* Index: SYS_MENU_PARENT_ID                                    */
/*==============================================================*/
create index SYS_MENU_PARENT_ID on SYS_MENU (
   PARENT_ID ASC
);

/*==============================================================*/
/* Index: SYS_MENU_PARENT_IDS                                   */
/*==============================================================*/
create index SYS_MENU_PARENT_IDS on SYS_MENU (
   PARENT_IDS ASC
);

/*==============================================================*/
/* Table: SYS_MOBILE_MENU                                       */
/*==============================================================*/
create table SYS_MOBILE_MENU 
(
   MENU_NO              VARCHAR2(64)         not null,
   MENU_TYPE            VARCHAR2(1),
   APP_ID               VARCHAR2(64),
   MENU_NAME            VARCHAR2(100),
   MENU_PAR_NO          VARCHAR2(64),
   MENU_SORT            NUMBER(10,0),
   MENU_IMG             VARCHAR2(100),
   MENU_URL             VARCHAR2(200),
   MENU_DESC            VARCHAR2(200),
   MENU_LEVEL           VARCHAR2(1),
   MENU_ABTYPE          VARCHAR2(10),
   MENU_STATUS          VARCHAR2(1),
   DEL_FLAG             VARCHAR2(1)          default '0',
   MUDULE_ID         VARCHAR2(64),
   constraint P_PK_MOBILE_MENU primary key (MENU_NO)
);

comment on table SYS_MOBILE_MENU is
'客户端菜单';

comment on column SYS_MOBILE_MENU.MENU_NO is
'菜单编号';

comment on column SYS_MOBILE_MENU.MENU_TYPE is
'菜单类型';

comment on column SYS_MOBILE_MENU.APP_ID is
'应用编号';

comment on column SYS_MOBILE_MENU.MENU_NAME is
'菜单名称';

comment on column SYS_MOBILE_MENU.MENU_PAR_NO is
'父菜单编号';

comment on column SYS_MOBILE_MENU.MENU_SORT is
'菜单排序';

comment on column SYS_MOBILE_MENU.MENU_IMG is
'菜单图标';

comment on column SYS_MOBILE_MENU.MENU_URL is
'菜单地址';

comment on column SYS_MOBILE_MENU.MENU_DESC is
'菜单描述';

comment on column SYS_MOBILE_MENU.MENU_LEVEL is
'菜单级别';

comment on column SYS_MOBILE_MENU.MENU_ABTYPE is
'菜单简称';

comment on column SYS_MOBILE_MENU.MENU_STATUS is
'菜单状态';

comment on column SYS_MOBILE_MENU.DEL_FLAG is
'删除标记';

/*==============================================================*/
/* Table: SYS_MOBILE_ROLE_MENU                                  */
/*==============================================================*/
create table SYS_MOBILE_ROLE_MENU 
(
   ROLE_ID              VARCHAR2(64)         not null,
   MENU_NO              VARCHAR2(64)         not null
);

comment on table SYS_MOBILE_ROLE_MENU is
'客户端菜单角色关系表';

comment on column SYS_MOBILE_ROLE_MENU.ROLE_ID is
'角色编号';

comment on column SYS_MOBILE_ROLE_MENU.MENU_NO is
'菜单编号';

/*==============================================================*/
/* Table: SYS_ORGAN                                             */
/*==============================================================*/
create table SYS_ORGAN 
(
   ID                   VARCHAR2(15)         not null,
   PARENT_ID            VARCHAR2(64)         not null,
   PARENT_IDS           VARCHAR2(2000)       not null,
   AREA_ID              VARCHAR2(64)         not null,
   CODE                 VARCHAR2(100),
   NAME                 VARCHAR2(100)        not null,
   TYPE                 VARCHAR2(1),
   GRADE                VARCHAR2(1)          not null,
   ADDRESS              VARCHAR2(255),
   ZIP_CODE             VARCHAR2(100),
   MASTER               VARCHAR2(100),
   PHONE                VARCHAR2(15),
   FAX                  VARCHAR2(200),
   EMAIL                VARCHAR2(255),
   CREATE_BY            VARCHAR2(64),
   CREATE_DATE          TIMESTAMP,
   UPDATE_BY            VARCHAR2(64),
   UPDATE_DATE          TIMESTAMP,
   REMARKS              VARCHAR2(255),
   DEL_FLAG             VARCHAR2(1)          default '0' not null,
   ORG_VALID            VARCHAR2(1),
   constraint SYS_C009139 primary key (ID)
);

comment on table SYS_ORGAN is
'机构表';

comment on column SYS_ORGAN.ID is
'编号';

comment on column SYS_ORGAN.PARENT_ID is
'父级编号';

comment on column SYS_ORGAN.PARENT_IDS is
'所有父级编号';

comment on column SYS_ORGAN.AREA_ID is
'归属区域';

comment on column SYS_ORGAN.CODE is
'区域编码';

comment on column SYS_ORGAN.NAME is
'机构名称';

comment on column SYS_ORGAN.TYPE is
'机构类型';

comment on column SYS_ORGAN.GRADE is
'机构等级';

comment on column SYS_ORGAN.ADDRESS is
'联系地址';

comment on column SYS_ORGAN.ZIP_CODE is
'邮政编码';

comment on column SYS_ORGAN.MASTER is
'负责人';

comment on column SYS_ORGAN.PHONE is
'电话';

comment on column SYS_ORGAN.FAX is
'传真';

comment on column SYS_ORGAN.EMAIL is
'邮箱';

comment on column SYS_ORGAN.CREATE_BY is
'创建者';

comment on column SYS_ORGAN.CREATE_DATE is
'创建时间';

comment on column SYS_ORGAN.UPDATE_BY is
'更新者';

comment on column SYS_ORGAN.UPDATE_DATE is
'更新时间';

comment on column SYS_ORGAN.REMARKS is
'备注信息';

comment on column SYS_ORGAN.DEL_FLAG is
'删除标记';

comment on column SYS_ORGAN.ORG_VALID is
'有效状态';

/*==============================================================*/
/* Index: SYS_OFFICE_DEL_FLAG                                   */
/*==============================================================*/
create index SYS_OFFICE_DEL_FLAG on SYS_ORGAN (
   DEL_FLAG ASC
);

/*==============================================================*/
/* Index: SYS_OFFICE_PARENT_ID                                  */
/*==============================================================*/
create index SYS_OFFICE_PARENT_ID on SYS_ORGAN (
   PARENT_ID ASC
);

/*==============================================================*/
/* Index: SYS_OFFICE_PARENT_IDS                                 */
/*==============================================================*/
create index SYS_OFFICE_PARENT_IDS on SYS_ORGAN (
   PARENT_IDS ASC
);

/*==============================================================*/
/* Table: SYS_ROLE                                              */
/*==============================================================*/
create table SYS_ROLE 
(
   ID                   VARCHAR2(64)         not null,
   OFFICE_ID            VARCHAR2(64),
   NAME                 VARCHAR2(100)        not null,
   DATA_SCOPE           VARCHAR2(1),
   CREATE_BY            VARCHAR2(64),
   CREATE_DATE          TIMESTAMP,
   UPDATE_BY            VARCHAR2(64),
   UPDATE_DATE          TIMESTAMP,
   REMARKS              VARCHAR2(255),
   DEL_FLAG             VARCHAR2(1)          default '0' not null,
   constraint SYS_C009140 primary key (ID)
);

comment on table SYS_ROLE is
'角色表';

comment on column SYS_ROLE.ID is
'编号';

comment on column SYS_ROLE.OFFICE_ID is
'归属机构';

comment on column SYS_ROLE.NAME is
'角色名称';

comment on column SYS_ROLE.DATA_SCOPE is
'数据范围';

comment on column SYS_ROLE.CREATE_BY is
'创建者';

comment on column SYS_ROLE.CREATE_DATE is
'创建时间';

comment on column SYS_ROLE.UPDATE_BY is
'更新者';

comment on column SYS_ROLE.UPDATE_DATE is
'更新时间';

comment on column SYS_ROLE.REMARKS is
'备注信息';

comment on column SYS_ROLE.DEL_FLAG is
'删除标记';

/*==============================================================*/
/* Index: SYS_ROLE_DEL_FLAG                                     */
/*==============================================================*/
create index SYS_ROLE_DEL_FLAG on SYS_ROLE (
   DEL_FLAG ASC
);

/*==============================================================*/
/* Table: SYS_ROLE_MENU                                         */
/*==============================================================*/
create table SYS_ROLE_MENU 
(
   ROLE_ID              VARCHAR2(64)         not null,
   MENU_ID              VARCHAR2(64)         not null,
   constraint SYS_C009141 primary key (ROLE_ID, MENU_ID)
);

comment on table SYS_ROLE_MENU is
'角色-菜单';

comment on column SYS_ROLE_MENU.ROLE_ID is
'角色编号';

comment on column SYS_ROLE_MENU.MENU_ID is
'菜单编号';

/*==============================================================*/
/* Table: SYS_ROLE_OFFICE                                       */
/*==============================================================*/
create table SYS_ROLE_OFFICE 
(
   ROLE_ID              VARCHAR2(64)         not null,
   OFFICE_ID            VARCHAR2(64)         not null,
   constraint SYS_C009142 primary key (ROLE_ID, OFFICE_ID)
);

comment on table SYS_ROLE_OFFICE is
'角色-机构';

comment on column SYS_ROLE_OFFICE.ROLE_ID is
'角色编号';

comment on column SYS_ROLE_OFFICE.OFFICE_ID is
'机构编号';

/*==============================================================*/
/* Table: SYS_USER                                              */
/*==============================================================*/
create table SYS_USER 
(
   ID                   VARCHAR2(64)         not null,
   COMPANY_ID           VARCHAR2(64),
   OFFICE_ID            VARCHAR2(64)         not null,
   LOGIN_NAME           VARCHAR2(100)        not null,
   PASSWORD             VARCHAR2(100)        not null,
   NO                   VARCHAR2(100),
   NAME                 VARCHAR2(200)        not null,
   EMAIL                VARCHAR2(255),
   PHONE                VARCHAR2(15),
   MOBILE               VARCHAR2(15),
   USER_TYPE            VARCHAR2(1),
   LOGIN_IP             VARCHAR2(15),
   LOGIN_DATE           TIMESTAMP,
   CREATE_BY            VARCHAR2(64),
   CREATE_DATE          TIMESTAMP,
   UPDATE_BY            VARCHAR2(64),
   UPDATE_DATE          TIMESTAMP,
   REMARKS              VARCHAR2(255),
   DEL_FLAG             VARCHAR2(1)          default '0' not null,
   DEVICE_MODEL         VARCHAR2(100),
   DEVICE_SYSTEM        VARCHAR2(100),
   USER_SEX             VARCHAR2(1)          default 'M',
   RSET_PSW_MARK        NUMBER(5,0),
   USE_FIRST_MARK       NUMBER(5,0),
   USER_STAUS           NUMBER(5,0),
   USER_END_DATE        VARCHAR2(20),
   ERR_LGN_CNT          NUMBER(5,0),
   USER_TYP             VARCHAR2(2),
   HEAD_IMG             VARCHAR2(255),
   LOGINTOKEN           VARCHAR2(32),
   FINGERPRINT          VARCHAR2(100),
   constraint SYS_C009143 primary key (ID)
);

comment on table SYS_USER is
'用户表';

comment on column SYS_USER.ID is
'编号';

comment on column SYS_USER.COMPANY_ID is
'归属公司';

comment on column SYS_USER.OFFICE_ID is
'归属部门';

comment on column SYS_USER.LOGIN_NAME is
'登录名';

comment on column SYS_USER.PASSWORD is
'密码';

comment on column SYS_USER.NO is
'工号';

comment on column SYS_USER.NAME is
'姓名';

comment on column SYS_USER.EMAIL is
'邮箱';

comment on column SYS_USER.PHONE is
'电话';

comment on column SYS_USER.MOBILE is
'手机';

comment on column SYS_USER.USER_TYPE is
'用户类型,0:后管+客户端，1：客户端，2：后管';

comment on column SYS_USER.LOGIN_IP is
'最后登陆IP';

comment on column SYS_USER.LOGIN_DATE is
'最后登陆时间';

comment on column SYS_USER.CREATE_BY is
'创建者';

comment on column SYS_USER.CREATE_DATE is
'创建时间';

comment on column SYS_USER.UPDATE_BY is
'更新者';

comment on column SYS_USER.UPDATE_DATE is
'更新时间';

comment on column SYS_USER.REMARKS is
'备注信息';

comment on column SYS_USER.DEL_FLAG is
'删除标记';

comment on column SYS_USER.DEVICE_MODEL is
'设备类型';

comment on column SYS_USER.DEVICE_SYSTEM is
'设备系统';

comment on column SYS_USER.USER_SEX is
'性别：M男F女';

comment on column SYS_USER.RSET_PSW_MARK is
'密码重置标志';

comment on column SYS_USER.USE_FIRST_MARK is
'首次密码标志';

comment on column SYS_USER.USER_STAUS is
'用户状态';

comment on column SYS_USER.USER_END_DATE is
'销户日期';

comment on column SYS_USER.ERR_LGN_CNT is
'密码错误次数';

comment on column SYS_USER.USER_TYP is
'用户类型';

comment on column SYS_USER.HEAD_IMG is
'用户头像';

/*==============================================================*/
/* Index: SYS_USER_COMPANY_ID                                   */
/*==============================================================*/
create index SYS_USER_COMPANY_ID on SYS_USER (
   COMPANY_ID ASC
);

/*==============================================================*/
/* Index: SYS_USER_DEL_FLAG                                     */
/*==============================================================*/
create index SYS_USER_DEL_FLAG on SYS_USER (
   DEL_FLAG ASC
);

/*==============================================================*/
/* Index: SYS_USER_LOGIN_NAME                                   */
/*==============================================================*/
create index SYS_USER_LOGIN_NAME on SYS_USER (
   LOGIN_NAME ASC
);

/*==============================================================*/
/* Index: SYS_USER_OFFICE_ID                                    */
/*==============================================================*/
create index SYS_USER_OFFICE_ID on SYS_USER (
   OFFICE_ID ASC
);

/*==============================================================*/
/* Index: SYS_USER_UPDATE_DATE                                  */
/*==============================================================*/
create index SYS_USER_UPDATE_DATE on SYS_USER (
   UPDATE_DATE ASC
);

/*==============================================================*/
/* Table: SYS_USER_ROLE                                         */
/*==============================================================*/
create table SYS_USER_ROLE 
(
   USER_ID              VARCHAR2(64)         not null,
   ROLE_ID              VARCHAR2(64)         not null,
   constraint SYS_C009144 primary key (USER_ID, ROLE_ID)
);

comment on table SYS_USER_ROLE is
'用户-角色';

comment on column SYS_USER_ROLE.USER_ID is
'用户编号';

comment on column SYS_USER_ROLE.ROLE_ID is
'角色编号';
